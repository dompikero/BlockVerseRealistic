Bu ilk sürüm harici doku dosyası kullanmaz; materyaller kodla üretilir.
