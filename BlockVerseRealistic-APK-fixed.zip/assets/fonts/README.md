Arayüz Godot tema fontunu kullanır; harici font kullanılmaz.
