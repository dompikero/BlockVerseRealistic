Harici ses dosyaları henüz bu prototipe eklenmemiştir; ses sistemi sonraki sürüm kapsamındadır.
