Dünya geometrisi runtime voxel chunk meshleriyle üretilir.
