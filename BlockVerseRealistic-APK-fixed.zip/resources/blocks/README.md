Blok türlerinin tanımı ve materyal renkleri `scripts/core/block_registry.gd` içindedir.
