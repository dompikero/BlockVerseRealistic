Üretim tarifleri `scripts/crafting/crafting_recipes.gd` içinde veri tabanlı tanımlıdır.
