Runtime materyaller `scripts/world/voxel_world.gd` içinde oluşturulur ve kullanılan shader dosyaları `shaders/` altındadır.
