İlk sürümde blok ve eşya kimlikleri envanter kayıtlarında string ID olarak kullanılır.
