# BlockVerse Realistic Mobile

BlockVerse Realistic, Godot 4 ile geliştirilen çevrimdışı bir voxel sandbox başlangıç oyunudur. Kaynak dosyalar, özgün shader'lar ve mobil APK CI iş akışı bu depoda tutulur.

> **Durum notu:** Bu teslimat oynanabilir çekirdek mekaniklere odaklanan ilk uygulamadır. Tam kapsamlı ticari oyun özelliği iddiasında değildir. Yerel ortamda Godot/Android araçları bulunmadığında gerçek APK ve motor testlerinin sonucu GitHub Actions çalıştırmasıyla doğrulanmalıdır.

## Sürüm ve araç zinciri

- Godot: **4.7.2 Stable**, GDScript, Mobile renderer (Android 9/API 28 ve üzeri hedeflenir).
- Android: ARM64 `arm64-v8a`, paket adı `com.blockverse.realistic`, sürüm `1.0.0`.
- Android export: resmî Godot export templates ile JDK 17 ve Android SDK platform 35 / build-tools 35.0.1 / NDK r28b. Mobile renderer nedeniyle hedeflenen minimum Android sürümü Android 9 (API 28).
- Harici eklenti, API anahtarı veya zorunlu çevrimiçi servis yok.

Godot sürümü, 18 Ağustos 2026 tarihli resmî arşivde Stable olarak listelenmiştir: https://godotengine.org/download/archive/4.7.2-stable/ . Android export gereksinimleri: https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html . Android 9/API 28 hedefi için resmî sistem gereksinimleri: https://docs.godotengine.org/en/4.7/about/system_requirements.html .

## Özellikler

- Seed ile tekrarlanabilir çok ölçekli gürültü tabanlı arazi, biome renkleri, yeraltı mağara boşlukları ve cevher dağılımı.
- 16×16 XZ chunk mesh birleştirmesi, görünmeyen yüzlerin elenmesi, chunk başına statik çarpışma ve sınırlı yükleme kuyruğu.
- Blok seçimi, basılı tutarak kırma, blok yerleştirme, kaynak toplama ve başlangıç hotbar envanteri.
- Dokunmatik joystick, çoklu parmak kamera girdisi, eylem alanları; klavye/fare desteği.
- Gün/gece renk geçişleri, dinamik yönlü ışık/gölgeler, atmosferik sis, hareketli dalgalı su, rüzgâr shader'ı, blok hedef vurgusu ve emissive shader.
- Envanter yığınları, tarif kontrolü ve basit üretim.
- Yerel JSON kayıtları; dünya seed'i, oyuncu durumu, envanter ve blok düzenlemeleri. Geçici dosya + yedekli değiştirme yaklaşımı.
- Hayatta kalma / yaratıcı başlangıç modu, grafik ve FPS ayarları, dünya menüsü, silme onayı ve otomatik kayıt.

## Projeyi açma

1. Godot 4.7.2 Stable'ı kurun.
2. `project.godot` dosyasını Godot Project Manager ile açın.
3. F6 ile ana sahneyi ya da F5 ile projeyi çalıştırın.
4. `Yeni Dünya` üzerinden seed ve modu seçin.

İlk açılışta shader derlemesi ve chunk mesh oluşturma kısa süreli performans etkisi yapabilir. Mobil cihazlarda daha düşük kalite kullanın.

## Kontroller

### PC

- `W A S D`: hareket; fare: bakış; `Space`: zıpla; `Shift`: koş.
- Sol tık basılı: blok kır; sağ tık: blok yerleştir.
- `1`–`9` veya fare tekerleği: hotbar.
- `Esc`: Godot varsayılan geri davranışı desteklenen platformlarda menü/duraklatma.

### Android dokunmatik

- Sol alt joystick: hareket.
- Sağ oyun alanını sürükleme: kamera.
- `ZIPLA`, `KIR`, `KOY`, `KOŞ`, `ÇANTA`, `Ⅱ`: hareket ve oyun eylemleri.

## Otomatik testler

Godot kurulu ortamda proje kökünden:

```bash
godot --headless --editor --path . --import
godot --headless --path . --script res://tests/run_tests.gd
```

Testler blok kayıt tablosu, seed tekrarlanabilirliği, arazi sınırları, envanter ekleme/çıkarma ve yığınlar, tarifler, kayıt-yükleme, bozuk kayıt yönetimi ve ayarların kalıcılığını çalıştırır.

## Yerel Android APK

1. Godot 4.7.2 export templates paketini kurun.
2. OpenJDK 17 ve Godot'un Android export belgelerinde belirtilen Android SDK/NDK paketlerini kurun.
3. Godot Editor Settings içinde Java SDK ve Android SDK yollarını ayarlayın.
4. `Android Debug` preset ile dışa aktarın:

```bash
mkdir -p build/android
godot --headless --path . --export-debug "Android Debug" build/android/BlockVerse-Realistic-debug.apk
unzip -t build/android/BlockVerse-Realistic-debug.apk
```

## GitHub Actions ile APK indirme

`.github/workflows/android-apk.yml`, `main` dalına push, pull request ve manuel `workflow_dispatch` olaylarında çalışır. Android SDK kurulumu `android-actions/setup-android@v4` ve Android command-line-tools 22.0 kullanır. Workflow proje içe aktarımını, GDScript testlerini ve Android ARM64 export'unu yapar; APK ZIP bütünlüğünü ve paket kimliğini denetler. Ancak başarılı doğrulamadan sonra `BlockVerse-Realistic-Android-APK` artifact'ını yayınlar. Her çalıştırma sonunda `BUILD_REPORT.md` raporu üretilir ve GitHub Actions özetine eklenir. Başarısız adımı ve konsol logundaki olası hata satırlarını gösteren `BlockVerse-Build-Report-and-Logs` artifact’ı da her durumda yüklenmeye çalışılır.

APK için **Actions → BlockVerse Android APK → başarılı çalıştırma → Artifacts → BlockVerse-Realistic-Android-APK** yolunu izleyin. Hata olduysa başarısız çalıştırmanın **Summary** kısmındaki `BUILD_REPORT.md` bölümünü veya `BlockVerse-Build-Report-and-Logs` artifact’ını açın. Repo bu ortamda GitHub’a bağlı değil; workflow henüz uzak bir Actions çalıştırmasında doğrulanmış değildir.

## Kayıt konumu

Kayıtlar Godot `user://worlds/` dizininde, ayarlar `user://settings.json` içinde tutulur. Android'de bunlar uygulamanın özel kullanıcı verisi dizinindedir.

## Özgünlük ve lisanslar

Özel dışarıdan alınmış doku, model, müzik veya ses varlığı bu ilk sürümde kullanılmamıştır. Arazi, materyal renkleri, su, yaprak, gökyüzü, hedef vurgusu ve emissive efektler projedeki özgün GDScript/shader koduyla oluşturulur. Font olarak Godot'un varsayılan temasındaki sistem fontu kullanılır. Proje kodu MIT lisansı kapsamındadır.

## Bilinen sınırlamalar

- Bu ilk kapsam tam gelişmiş ticari sandbox değildir: tüm listelenen blokların özel geometrileri, tam crafting-table UI'si, gerçek açlık/düşman savaş döngüsü, hayvan animasyonları, gerçek sualtı post-process'i, yağış simülasyonu ve tüm ses varlıkları henüz tamamlanmış sayılmaz.
- Dünya yüksekliği sınırı 128 olarak tanımlanmıştır; arazi yüzeyi daha alçak bir aralıkta üretilir. Yüklenen chunk'lar uzaklaşınca kaldırılır, ancak disk tabanlı büyük dünya/region sistemi değildir.
- Procedural blok materyalleri özgün renk tabanlı materyallerdir; ayrı albedo/normal PBR doku atlası henüz bulunmaz.
- Godot motoru, SDK, APK veya gerçek cihaz testi yerel ortamda doğrulanmadıysa başarılı olarak raporlanmamalıdır.
