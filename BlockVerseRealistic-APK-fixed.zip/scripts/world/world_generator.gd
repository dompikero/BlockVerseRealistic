extends RefCounted
class_name WorldGenerator

const WORLD_HEIGHT := 128
var seed_value: int = 1337
var height_noise: FastNoiseLite
var detail_noise: FastNoiseLite
var biome_noise: FastNoiseLite
var cave_noise: FastNoiseLite
var ore_noise: FastNoiseLite

func configure(new_seed: int) -> void:
    seed_value = new_seed
    height_noise = FastNoiseLite.new()
    height_noise.seed = seed_value
    height_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    height_noise.frequency = 0.009
    height_noise.fractal_octaves = 4
    height_noise.fractal_gain = 0.52
    detail_noise = FastNoiseLite.new()
    detail_noise.seed = seed_value ^ 0x5F3759DF
    detail_noise.frequency = 0.035
    detail_noise.fractal_octaves = 3
    biome_noise = FastNoiseLite.new()
    biome_noise.seed = seed_value ^ 0x2C9277B5
    biome_noise.frequency = 0.0038
    cave_noise = FastNoiseLite.new()
    cave_noise.seed = seed_value ^ 0x165667B1
    cave_noise.frequency = 0.045
    cave_noise.fractal_octaves = 2
    ore_noise = FastNoiseLite.new()
    ore_noise.seed = seed_value ^ 0x27D4EB2D
    ore_noise.frequency = 0.12

func height_at(x: int, z: int) -> int:
    var broad := height_noise.get_noise_2d(float(x), float(z))
    var detail := detail_noise.get_noise_2d(float(x), float(z))
    var ridge := 1.0 - absf(detail_noise.get_noise_2d(float(x) * 0.31 + 250.0, float(z) * 0.31 - 90.0))
    return clampi(int(round(17.0 + broad * 10.0 + detail * 3.0 + ridge * maxf(0.0, broad) * 7.0)), 5, 47)

func biome_at(x: int, z: int) -> String:
    var climate := biome_noise.get_noise_2d(float(x), float(z))
    var wet := detail_noise.get_noise_2d(float(x) + 913.0, float(z) - 527.0)
    var h := height_at(x, z)
    if h >= 35:
        return "mountain"
    if climate < -0.55:
        return "desert"
    if climate > 0.60:
        return "snow"
    if wet < -0.48:
        return "stony"
    if absf(climate) < 0.12 and h < 12:
        return "beach"
    if wet > 0.22:
        return "forest"
    return "plains"

func block_at(pos: Vector3i) -> String:
    if pos.y < 0 or pos.y >= WORLD_HEIGHT:
        return ""
    var h := height_at(pos.x, pos.z)
    if pos.y > h:
        return ""
    if pos.y > 3 and pos.y < h - 3 and absf(cave_noise.get_noise_3d(float(pos.x) * 0.7, float(pos.y) * 0.7, float(pos.z) * 0.7)) > 0.69:
        return ""
    var biome := biome_at(pos.x, pos.z)
    if pos.y == h:
        if biome == "desert" or biome == "beach":
            return "sand"
        if biome == "snow" or (biome == "mountain" and h > 38):
            return "snow"
        if biome == "stony" or biome == "mountain":
            return "stone"
        return "grass"
    if pos.y >= h - 3:
        if biome == "desert" or biome == "beach":
            return "sand"
        if biome == "snow":
            return "dirt" if pos.y < h - 1 else "snow"
        return "dirt"
    var ore := ore_noise.get_noise_3d(float(pos.x) + 12.0, float(pos.y) * 1.8, float(pos.z) - 64.0)
    if pos.y < 20 and ore > 0.65:
        if pos.y < 10 and ore > 0.78:
            return "diamond_ore"
        return "iron_ore" if ore > 0.72 else "coal_ore"
    if pos.y < 28 and ore < -0.69:
        return "copper_ore"
    if pos.y < 13 and ore > 0.54 and ore < 0.60:
        return "gold_ore"
    return "stone"
