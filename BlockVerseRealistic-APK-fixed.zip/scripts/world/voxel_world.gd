extends Node3D
class_name VoxelWorld

const CHUNK_SIZE := 16
const WORLD_HEIGHT := 128
const LOAD_RADIUS_DEFAULT := 2
const BlockRegistryScript = preload("res://scripts/core/block_registry.gd")
const GeneratorScript = preload("res://scripts/world/world_generator.gd")
const FOLIAGE_SHADER = preload("res://shaders/foliage.gdshader")
const WATER_SHADER = preload("res://shaders/water.gdshader")
const SKY_SHADER = preload("res://shaders/sky.gdshader")

var generator: WorldGenerator
var seed_value: int = 1337
var block_overrides: Dictionary = {}
var tree_blocks: Dictionary = {}
var base_block_cache: Dictionary = {}
var chunks: Dictionary = {}
var pending_chunks: Array[Vector2i] = []
var materials: Dictionary = {}
var world_environment: WorldEnvironment
var sun: DirectionalLight3D
var water_node: MeshInstance3D
var elapsed_day_time: float = 0.28
var day_cycle_enabled := true
var chunk_radius := LOAD_RADIUS_DEFAULT
var current_center := Vector2i(0, 0)
var load_budget_per_frame := 1
var _last_center := Vector2i(999999, 999999)

func _ready() -> void:
    _create_environment()
    _create_materials()

func initialize_world(new_seed: int, serialized_edits: Array = []) -> void:
    seed_value = new_seed
    generator = GeneratorScript.new()
    generator.configure(seed_value)
    for chunk_value in chunks.values():
        if is_instance_valid(chunk_value):
            chunk_value.queue_free()
    chunks.clear()
    pending_chunks.clear()
    tree_blocks.clear()
    base_block_cache.clear()
    block_overrides.clear()
    for edit in serialized_edits:
        if edit is Dictionary:
            var pos := Vector3i(int(edit.get("x", 0)), int(edit.get("y", 0)), int(edit.get("z", 0)))
            var block_id := str(edit.get("id", ""))
            if block_id.is_empty() or BlockRegistryScript.has_block(block_id):
                block_overrides[pos] = block_id
    _last_center = Vector2i(999999, 999999)
    update_streaming(Vector3.ZERO, chunk_radius)

func _create_environment() -> void:
    world_environment = WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_material := ShaderMaterial.new()
    sky_material.shader = SKY_SHADER
    sky.sky_material = sky_material
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.56, 0.65, 0.72)
    env.ambient_light_energy = 0.75
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.55, 0.67, 0.72)
    env.fog_density = 0.0018
    world_environment.environment = env
    add_child(world_environment)
    sun = DirectionalLight3D.new()
    sun.name = "DynamicSun"
    sun.rotation_degrees = Vector3(-38.0, 35.0, 0.0)
    sun.light_color = Color(1.0, 0.91, 0.77)
    sun.light_energy = 1.2
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 72.0
    add_child(sun)
    var water_mesh := PlaneMesh.new()
    water_mesh.size = Vector2(1024, 1024)
    water_mesh.subdivide_width = 64
    water_mesh.subdivide_depth = 64
    water_node = MeshInstance3D.new()
    water_node.name = "AnimatedWater"
    water_node.mesh = water_mesh
    water_node.position.y = 10.0
    var water_material := ShaderMaterial.new()
    water_material.shader = WATER_SHADER
    water_node.material_override = water_material
    add_child(water_node)

func _create_materials() -> void:
    for block_id in BlockRegistryScript.ids():
        var data: Dictionary = BlockRegistryScript.get_block(block_id)
        if block_id == "leaves":
            var leaf_material := ShaderMaterial.new()
            leaf_material.shader = FOLIAGE_SHADER
            leaf_material.set_shader_parameter("leaf_tint", data.color)
            materials[block_id] = leaf_material
            continue
        if block_id == "torch":
            var glow_material := ShaderMaterial.new()
            glow_material.shader = preload("res://shaders/emissive.gdshader")
            glow_material.set_shader_parameter("surface_color", Color(data.color))
            glow_material.set_shader_parameter("glow_color", Color(1.0, 0.35, 0.08))
            glow_material.set_shader_parameter("glow_energy", 2.1)
            materials[block_id] = glow_material
            continue
        var material := StandardMaterial3D.new()
        material.albedo_color = data.color
        material.roughness = 0.94
        material.cull_mode = BaseMaterial3D.CULL_DISABLED
        if block_id == "glass":
            material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
            material.roughness = 0.13
        elif block_id.ends_with("_ore"):
            material.roughness = 0.62
            material.metallic = 0.16
        elif block_id == "sand":
            material.roughness = 0.98
        elif block_id == "wood" or block_id == "planks":
            material.roughness = 0.83
        materials[block_id] = material

func _process(delta: float) -> void:
    if generator == null:
        generator = GeneratorScript.new()
        generator.configure(seed_value)
    for i in range(mini(load_budget_per_frame, pending_chunks.size())):
        var coord: Vector2i = pending_chunks.pop_front()
        if not chunks.has(coord) and coord.distance_to(current_center) <= float(chunk_radius + 1):
            _build_chunk(coord)
    if day_cycle_enabled:
        elapsed_day_time = fposmod(elapsed_day_time + delta / 420.0, 1.0)
        _update_daylight()

func update_streaming(world_position: Vector3, radius: int = -1) -> void:
    if radius >= 0:
        chunk_radius = clampi(radius, 1, 6)
    current_center = Vector2i(floori(world_position.x / CHUNK_SIZE), floori(world_position.z / CHUNK_SIZE))
    if current_center != _last_center:
        _last_center = current_center
        for z in range(-chunk_radius, chunk_radius + 1):
            for x in range(-chunk_radius, chunk_radius + 1):
                var coord := current_center + Vector2i(x, z)
                if not chunks.has(coord) and not pending_chunks.has(coord):
                    pending_chunks.append(coord)
        pending_chunks.sort_custom(func(a: Vector2i, b: Vector2i) -> bool: return a.distance_squared_to(current_center) < b.distance_squared_to(current_center))
        for coord in chunks.keys():
            if coord.distance_to(current_center) > float(chunk_radius + 2):
                var chunk_node: Node = chunks[coord]
                chunks.erase(coord)
                if is_instance_valid(chunk_node):
                    chunk_node.queue_free()
        for i in range(pending_chunks.size() - 1, -1, -1):
            if pending_chunks[i].distance_to(current_center) > float(chunk_radius + 1):
                pending_chunks.remove_at(i)

func height_at(x: int, z: int) -> int:
    return generator.height_at(x, z) if generator != null else 16

func get_block(pos: Vector3i) -> String:
    if block_overrides.has(pos):
        return str(block_overrides[pos])
    if tree_blocks.has(pos):
        return str(tree_blocks[pos])
    if base_block_cache.has(pos):
        return str(base_block_cache[pos])
    var generated := generator.block_at(pos) if generator != null else ""
    base_block_cache[pos] = generated
    return generated

func set_block(pos: Vector3i, block_id: String) -> bool:
    if pos.y < 0 or pos.y >= WORLD_HEIGHT:
        return false
    if not block_id.is_empty() and not BlockRegistryScript.has_block(block_id):
        return false
    block_overrides[pos] = block_id
    var center := Vector2i(floori(float(pos.x) / CHUNK_SIZE), floori(float(pos.z) / CHUNK_SIZE))
    _rebuild_chunk_if_loaded(center)
    var local_x := pos.x - center.x * CHUNK_SIZE
    var local_z := pos.z - center.y * CHUNK_SIZE
    if local_x == 0: _rebuild_chunk_if_loaded(center + Vector2i(-1, 0))
    if local_x == CHUNK_SIZE - 1: _rebuild_chunk_if_loaded(center + Vector2i(1, 0))
    if local_z == 0: _rebuild_chunk_if_loaded(center + Vector2i(0, -1))
    if local_z == CHUNK_SIZE - 1: _rebuild_chunk_if_loaded(center + Vector2i(0, 1))
    return true

func serialize_edits() -> Array:
    var serialized: Array = []
    for pos in block_overrides:
        serialized.append({"x":pos.x, "y":pos.y, "z":pos.z, "id":str(block_overrides[pos])})
    return serialized

func _rebuild_chunk_if_loaded(coord: Vector2i) -> void:
    if not chunks.has(coord):
        return
    var old: Node = chunks[coord]
    chunks.erase(coord)
    if is_instance_valid(old): old.queue_free()
    _build_chunk(coord)

func _prepare_trees(coord: Vector2i) -> void:
    var base_x := coord.x * CHUNK_SIZE - 2
    var base_z := coord.y * CHUNK_SIZE - 2
    for x in range(base_x, base_x + CHUNK_SIZE + 4):
        for z in range(base_z, base_z + CHUNK_SIZE + 4):
            var hash_value := absi((x * 73856093) ^ (z * 19349663) ^ (seed_value * 83492791)) % 131
            if hash_value > 3:
                continue
            var biome := generator.biome_at(x, z)
            if biome == "desert" or biome == "beach" or biome == "snow" or biome == "mountain" or biome == "stony":
                continue
            var ground_y := generator.height_at(x, z)
            if ground_y < 10:
                continue
            for trunk_y in range(1, 5):
                tree_blocks[Vector3i(x, ground_y + trunk_y, z)] = "wood"
            for dy in range(2, 6):
                var radius := 2 if dy <= 3 else 1
                for dx in range(-radius, radius + 1):
                    for dz in range(-radius, radius + 1):
                        if abs(dx) + abs(dz) > radius * 2 or (dx == 0 and dz == 0 and dy < 4):
                            continue
                        var leaf_pos := Vector3i(x + dx, ground_y + dy, z + dz)
                        if not tree_blocks.has(leaf_pos): tree_blocks[leaf_pos] = "leaves"

func _build_chunk(coord: Vector2i) -> void:
    if generator == null:
        return
    _prepare_trees(coord)
    var builders: Dictionary = {}
    var start_x := coord.x * CHUNK_SIZE
    var start_z := coord.y * CHUNK_SIZE
    for lx in range(CHUNK_SIZE):
        for lz in range(CHUNK_SIZE):
            var gx := start_x + lx
            var gz := start_z + lz
            var top := generator.height_at(gx, gz)
            for y in range(0, min(WORLD_HEIGHT, top + 7)):
                var p := Vector3i(gx, y, gz)
                var block_id := get_block(p)
                if block_id.is_empty() or not materials.has(block_id):
                    continue
                var faces: Array = [
                    {"d":Vector3i(1,0,0), "v":[Vector3(lx+1,y,lz),Vector3(lx+1,y+1,lz),Vector3(lx+1,y+1,lz+1),Vector3(lx+1,y,lz+1)], "n":Vector3.RIGHT},
                    {"d":Vector3i(-1,0,0), "v":[Vector3(lx,y,lz+1),Vector3(lx,y+1,lz+1),Vector3(lx,y+1,lz),Vector3(lx,y,lz)], "n":Vector3.LEFT},
                    {"d":Vector3i(0,1,0), "v":[Vector3(lx,y+1,lz+1),Vector3(lx+1,y+1,lz+1),Vector3(lx+1,y+1,lz),Vector3(lx,y+1,lz)], "n":Vector3.UP},
                    {"d":Vector3i(0,-1,0), "v":[Vector3(lx,y,lz),Vector3(lx+1,y,lz),Vector3(lx+1,y,lz+1),Vector3(lx,y,lz+1)], "n":Vector3.DOWN},
                    {"d":Vector3i(0,0,1), "v":[Vector3(lx+1,y,lz+1),Vector3(lx+1,y+1,lz+1),Vector3(lx,y+1,lz+1),Vector3(lx,y,lz+1)], "n":Vector3.BACK},
                    {"d":Vector3i(0,0,-1), "v":[Vector3(lx,y,lz),Vector3(lx,y+1,lz),Vector3(lx+1,y+1,lz),Vector3(lx+1,y,lz)], "n":Vector3.FORWARD}
                ]
                for face in faces:
                    var neighbour := get_block(p + face.d)
                    if not neighbour.is_empty() and (neighbour == block_id or not (BlockRegistryScript.is_transparent(block_id) and BlockRegistryScript.is_transparent(neighbour))):
                        continue
                    if not builders.has(block_id):
                        var surface := SurfaceTool.new()
                        surface.begin(Mesh.PRIMITIVE_TRIANGLES)
                        builders[block_id] = surface
                    var st: SurfaceTool = builders[block_id]
                    var verts: Array = face.v
                    _append_triangle(st, verts[0], verts[1], verts[2], face.n, Vector2(0,0), Vector2(0,1), Vector2(1,1))
                    _append_triangle(st, verts[0], verts[2], verts[3], face.n, Vector2(0,0), Vector2(1,1), Vector2(1,0))
    var merged := ArrayMesh.new()
    for block_id in builders:
        var st: SurfaceTool = builders[block_id]
        st.generate_tangents()
        var surface_index := merged.get_surface_count()
        st.commit(merged)
        merged.surface_set_material(surface_index, materials[block_id])
    var chunk_node := StaticBody3D.new()
    chunk_node.name = "Chunk_%d_%d" % [coord.x, coord.y]
    chunk_node.position = Vector3(start_x, 0, start_z)
    chunk_node.collision_layer = 1
    chunk_node.collision_mask = 1
    if merged.get_surface_count() > 0:
        var mesh_instance := MeshInstance3D.new()
        mesh_instance.mesh = merged
        mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
        chunk_node.add_child(mesh_instance)
        var collision := CollisionShape3D.new()
        collision.shape = merged.create_trimesh_shape()
        chunk_node.add_child(collision)
    add_child(chunk_node)
    chunks[coord] = chunk_node

func _append_triangle(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, normal: Vector3, uv_a: Vector2, uv_b: Vector2, uv_c: Vector2) -> void:
    st.set_normal(normal)
    st.set_uv(uv_a)
    st.add_vertex(a)
    st.set_normal(normal)
    st.set_uv(uv_b)
    st.add_vertex(b)
    st.set_normal(normal)
    st.set_uv(uv_c)
    st.add_vertex(c)

func _update_daylight() -> void:
    var angle := elapsed_day_time * TAU
    sun.rotation = Vector3(deg_to_rad(-90.0) + angle, deg_to_rad(35.0), 0.0)
    var daylight := clampf(sin(angle) * 0.5 + 0.5, 0.05, 1.0)
    var sunrise := clampf(1.0 - absf(daylight - 0.42) * 4.2, 0.0, 1.0)
    sun.light_energy = 0.08 + daylight * 1.35
    sun.light_color = Color(1.0, 0.62, 0.42).lerp(Color(1.0, 0.95, 0.84), daylight) if sunrise > 0.0 else Color(1.0, 0.93, 0.82)
    sun.shadow_enabled = daylight > 0.10
    if world_environment.environment.sky.sky_material is ShaderMaterial:
        (world_environment.environment.sky.sky_material as ShaderMaterial).set_shader_parameter("time_of_day", elapsed_day_time)
    world_environment.environment.ambient_light_energy = 0.16 + daylight * 0.7
    world_environment.environment.fog_light_color = Color(0.26, 0.31, 0.40).lerp(Color(0.60, 0.72, 0.76), daylight)
    world_environment.environment.fog_density = 0.0022 - daylight * 0.0006

func set_quality(quality: String) -> void:
    match quality:
        "low":
            chunk_radius = 2
            load_budget_per_frame = 1
            sun.directional_shadow_max_distance = 38.0
            sun.shadow_enabled = false
        "high":
            chunk_radius = 5
            load_budget_per_frame = 1
            sun.directional_shadow_max_distance = 100.0
            sun.shadow_enabled = true
        _:
            chunk_radius = 3
            load_budget_per_frame = 1
            sun.directional_shadow_max_distance = 68.0
            sun.shadow_enabled = true
    _last_center = Vector2i(999999, 999999)
