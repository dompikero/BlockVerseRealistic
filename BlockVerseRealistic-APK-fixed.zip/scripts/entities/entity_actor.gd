extends CharacterBody3D
class_name EntityActor

@export_enum("passive", "hostile") var behavior: String = "passive"
@export var movement_speed := 2.4
@export var max_health := 6.0
var health := 6.0
var target: Node3D
var world: VoxelWorld
var _think_timer := 0.0
var _direction := Vector3.ZERO
var _state := "idle"
var _attack_cooldown := 0.0

func _ready() -> void:
    health = max_health

func configure(world_ref: VoxelWorld, player_ref: Node3D) -> void:
    world = world_ref
    target = player_ref

func _physics_process(delta: float) -> void:
    _think_timer -= delta
    _attack_cooldown = maxf(0.0, _attack_cooldown - delta)
    if behavior == "hostile" and target != null and global_position.distance_to(target.global_position) < 1.6 and _attack_cooldown <= 0.0:
        if target.has_method("take_damage"):
            target.take_damage(2.0)
        _attack_cooldown = 1.25
    if _think_timer <= 0.0:
        _think_timer = randf_range(0.8, 2.2)
        _think()
    if not is_on_floor():
        velocity.y -= 24.0 * delta
    else:
        velocity.y = -0.5
    velocity.x = move_toward(velocity.x, _direction.x * movement_speed, delta * 6.0)
    velocity.z = move_toward(velocity.z, _direction.z * movement_speed, delta * 6.0)
    move_and_slide()

func _think() -> void:
    if target != null and global_position.distance_to(target.global_position) < 15.0:
        if behavior == "hostile" and global_position.distance_to(target.global_position) > 1.5:
            _state = "chase"
            _direction = (target.global_position - global_position).normalized()
            _direction.y = 0.0
            movement_speed = 3.0
            return
        if behavior == "passive" and global_position.distance_to(target.global_position) < 5.5:
            _state = "flee"
            _direction = (global_position - target.global_position).normalized()
            _direction.y = 0.0
            movement_speed = 3.5
            return
    _state = "wander"
    _direction = Vector3(randf_range(-1,1),0,randf_range(-1,1)).normalized()
    movement_speed = 1.4 if behavior == "passive" else 2.2

func take_damage(amount: float) -> bool:
    health -= amount
    if health <= 0.0:
        queue_free()
        return true
    return false
