extends RefCounted
class_name SaveManager

const SAVE_VERSION := 1

static func _safe_id(world_id: String) -> String:
    var safe := ""
    for character in world_id.to_lower():
        if character in "abcdefghijklmnopqrstuvwxyz0123456789_-":
            safe += character
        elif character == " " or character == ".":
            safe += "_"
    return safe.left(48) if not safe.is_empty() else "world"

static func save_path(world_id: String) -> String:
    return "user://worlds/" + _safe_id(world_id) + ".json"

static func save_world(world_id: String, payload: Dictionary) -> bool:
    var directory := DirAccess.open("user://")
    if directory == null:
        return false
    if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path("user://worlds")):
        if directory.make_dir("worlds") != OK and not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path("user://worlds")):
            return false
    var final_path := save_path(world_id)
    var temp_path := final_path + ".tmp"
    var file := FileAccess.open(temp_path, FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify({"save_version":SAVE_VERSION, "payload":payload}, "\t"))
    file.flush()
    var write_error := file.get_error()
    file.close()
    if write_error != OK:
        return false
    var absolute_final := ProjectSettings.globalize_path(final_path)
    var absolute_temp := ProjectSettings.globalize_path(temp_path)
    var absolute_backup := absolute_final + ".bak"
    if FileAccess.file_exists(final_path):
        if FileAccess.file_exists(absolute_backup):
            DirAccess.remove_absolute(absolute_backup)
        var backup_error := DirAccess.rename_absolute(absolute_final, absolute_backup)
        if backup_error != OK:
            DirAccess.remove_absolute(absolute_temp)
            return false
    var rename_error := DirAccess.rename_absolute(absolute_temp, absolute_final)
    if rename_error != OK:
        if FileAccess.file_exists(absolute_backup):
            DirAccess.rename_absolute(absolute_backup, absolute_final)
        return false
    if FileAccess.file_exists(absolute_backup):
        DirAccess.remove_absolute(absolute_backup)
    return true

static func load_world(world_id: String) -> Dictionary:
    var path := save_path(world_id)
    if not FileAccess.file_exists(path):
        return {"ok":false, "error":"Kayıt bulunamadı."}
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return {"ok":false, "error":"Kayıt dosyası açılamadı."}
    var text := file.get_as_text()
    file.close()
    var parsed: Variant = JSON.parse_string(text)
    if not parsed is Dictionary:
        return {"ok":false, "error":"Kayıt dosyası bozuk veya geçersiz JSON."}
    if int(parsed.get("save_version", -1)) != SAVE_VERSION or not parsed.get("payload", null) is Dictionary:
        return {"ok":false, "error":"Kayıt sürümü desteklenmiyor."}
    return {"ok":true, "data":parsed.payload}

static func list_worlds() -> Array[Dictionary]:
    var results: Array[Dictionary] = []
    var absolute_dir := ProjectSettings.globalize_path("user://worlds")
    if not DirAccess.dir_exists_absolute(absolute_dir):
        return results
    var dir := DirAccess.open("user://worlds")
    if dir == null:
        return results
    dir.list_dir_begin()
    var file_name := dir.get_next()
    while not file_name.is_empty():
        if not dir.current_is_dir() and file_name.ends_with(".json") and not file_name.ends_with(".tmp"):
            var file := FileAccess.open("user://worlds/" + file_name, FileAccess.READ)
            if file != null:
                var parsed: Variant = JSON.parse_string(file.get_as_text())
                file.close()
                if parsed is Dictionary and parsed.get("payload", null) is Dictionary:
                    var payload: Dictionary = parsed.payload
                    results.append({"id":file_name.trim_suffix(".json"), "name":str(payload.get("name", file_name)), "seed":int(payload.get("seed", 0)), "mode":str(payload.get("mode", "survival")), "last_played":str(payload.get("last_played", ""))})
        file_name = dir.get_next()
    dir.list_dir_end()
    results.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return str(a.name) < str(b.name))
    return results

static func delete_world(world_id: String) -> bool:
    var path := save_path(world_id)
    if not FileAccess.file_exists(path):
        return false
    return DirAccess.remove_absolute(ProjectSettings.globalize_path(path)) == OK
