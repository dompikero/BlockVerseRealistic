extends Control
class_name GameHUD

signal jump_requested
signal place_requested
signal inventory_requested
signal pause_requested
signal slot_selected(index: int)
signal break_started
signal break_stopped

var move_vector := Vector2.ZERO
var sprinting := false
var jump_down := false
var breaking := false
var _joystick_id := -1
var _joystick_origin := Vector2.ZERO
var _joystick_knob := Vector2.ZERO
var _touch_actions: Dictionary = {}
var selected_slot := 0
var viewport_size := Vector2(1280, 720)

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    set_process_input(true)

func _draw() -> void:
    viewport_size = get_viewport_rect().size
    var w := viewport_size.x
    var h := viewport_size.y
    draw_circle(Vector2(104, h - 111), 66.0, Color(0.02, 0.04, 0.06, 0.25))
    draw_arc(Vector2(104, h - 111), 63.0, 0, TAU, 48, Color(0.85, 0.91, 0.94, 0.34), 2.0, true)
    draw_circle(_joystick_knob if _joystick_id != -1 else Vector2(104, h - 111), 28.0, Color(0.90, 0.95, 0.98, 0.28))
    draw_line(Vector2(w * 0.5 - 9, h * 0.5), Vector2(w * 0.5 + 9, h * 0.5), Color(1,1,1,0.9), 2.0)
    draw_line(Vector2(w * 0.5, h * 0.5 - 9), Vector2(w * 0.5, h * 0.5 + 9), Color(1,1,1,0.9), 2.0)
    _draw_button(Vector2(w - 85, h - 100), 43, "ZIPLA", _touch_actions.has("jump"))
    _draw_button(Vector2(w - 178, h - 91), 38, "KIR", breaking)
    _draw_button(Vector2(w - 91, h - 190), 37, "KOY", _touch_actions.has("place"))
    _draw_button(Vector2(w - 265, h - 68), 29, "KOŞ", sprinting)
    _draw_button(Vector2(w - 58, 55), 25, "Ⅱ", false)
    _draw_button(Vector2(w - 300, h - 160), 30, "ÇANTA", false)
    var slot_w := 50.0
    var start_x := w * 0.5 - slot_w * 4.5
    for i in range(9):
        var rect := Rect2(Vector2(start_x + i * slot_w, h - 58), Vector2(slot_w - 3, 46))
        draw_rect(rect, Color(0.035, 0.055, 0.075, 0.70), true)
        draw_rect(rect, Color(1.0, 0.72, 0.32, 0.94) if i == selected_slot else Color(0.75,0.82,0.86,0.42), false, 2.0 if i == selected_slot else 1.0)
        draw_string(ThemeDB.fallback_font, rect.position + Vector2(6, 16), str(i + 1), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(1,1,1,0.8))

func _draw_button(center: Vector2, radius: float, label_text: String, active: bool) -> void:
    draw_circle(center, radius, Color(0.05,0.08,0.11,0.82) if active else Color(0.08,0.12,0.15,0.52))
    draw_arc(center, radius, 0.0, TAU, 36, Color(1.0,0.76,0.40,0.90) if active else Color(0.84,0.90,0.94,0.48), 2.0, true)
    draw_string(ThemeDB.fallback_font, center + Vector2(-radius + 5, 5), label_text, HORIZONTAL_ALIGNMENT_CENTER, radius * 2.0 - 10, 12 if label_text.length() > 3 else 14, Color.WHITE)

func _input(event: InputEvent) -> void:
    viewport_size = get_viewport_rect().size
    var w := viewport_size.x
    var h := viewport_size.y
    if event is InputEventScreenTouch:
        if event.pressed:
            var p: Vector2 = event.position
            if p.x < w * 0.33 and p.y > h * 0.52 and _joystick_id == -1:
                _joystick_id = event.index
                _joystick_origin = Vector2(104, h - 111)
                _joystick_knob = p
                _update_move(p)
            elif _hit(p, Vector2(w - 85, h - 100), 45):
                _touch_actions["jump"] = event.index
                jump_down = true
                jump_requested.emit()
            elif _hit(p, Vector2(w - 178, h - 91), 40):
                breaking = true
                _touch_actions["break"] = event.index
                break_started.emit()
            elif _hit(p, Vector2(w - 91, h - 190), 39):
                _touch_actions["place"] = event.index
                place_requested.emit()
            elif _hit(p, Vector2(w - 265, h - 68), 31):
                sprinting = true
                _touch_actions["sprint"] = event.index
            elif _hit(p, Vector2(w - 58, 55), 28):
                pause_requested.emit()
            elif _hit(p, Vector2(w - 300, h - 160), 32):
                inventory_requested.emit()
            else:
                var slot_w := 50.0
                var start_x := w * 0.5 - slot_w * 4.5
                if p.y >= h - 63 and p.y <= h - 10:
                    var slot_idx := int(floor((p.x - start_x) / slot_w))
                    if slot_idx >= 0 and slot_idx < 9:
                        selected_slot = slot_idx
                        slot_selected.emit(slot_idx)
            queue_redraw()
        else:
            if event.index == _joystick_id:
                _joystick_id = -1
                move_vector = Vector2.ZERO
                _joystick_knob = Vector2(104, h - 111)
            for key in _touch_actions.keys().duplicate():
                if int(_touch_actions[key]) == event.index:
                    _touch_actions.erase(key)
                    if key == "jump": jump_down = false
                    elif key == "break":
                        breaking = false
                        break_stopped.emit()
                    elif key == "sprint": sprinting = false
            queue_redraw()
    elif event is InputEventScreenDrag and event.index == _joystick_id:
        _joystick_knob = event.position
        _update_move(event.position)
        queue_redraw()
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.keycode >= KEY_1 and event.keycode <= KEY_9:
            selected_slot = event.keycode - KEY_1
            slot_selected.emit(selected_slot)
            queue_redraw()

func _update_move(position: Vector2) -> void:
    var delta := position - _joystick_origin
    move_vector = Vector2(delta.x, delta.y) / 54.0
    move_vector = move_vector.limit_length(1.0)
    _joystick_knob = _joystick_origin + delta.limit_length(46.0)

func _hit(point: Vector2, center: Vector2, radius: float) -> bool:
    return point.distance_to(center) <= radius
