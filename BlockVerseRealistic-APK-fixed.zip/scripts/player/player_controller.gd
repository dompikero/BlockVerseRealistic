extends CharacterBody3D
class_name PlayerController

const GRAVITY := 24.0
const WALK_SPEED := 5.2
const SPRINT_SPEED := 8.0
const JUMP_VELOCITY := 8.2
const MAX_HEALTH := 20.0
const BlockRegistryScript = preload("res://scripts/core/block_registry.gd")

@onready var camera: Camera3D = $Camera3D
@onready var ray: RayCast3D = $Camera3D/RayCast3D
var world: VoxelWorld
var inventory: InventoryModel = InventoryModel.new()
var mobile_move := Vector2.ZERO
var mobile_sprinting := false
var mobile_jump := false
var is_creative := false
var health := MAX_HEALTH
var hunger := 20.0
var mining_progress := 0.0
var mining_position := Vector3i(999999, 0, 0)
var last_hit_block := ""
var fall_start_y := 0.0
var look_sensitivity := 0.0024
var camera_pitch := 0.0
var break_held := false
var _look_touch_id := -1
var _last_touch_position := Vector2.ZERO
var highlight: MeshInstance3D
var _highlight_material: ShaderMaterial

func _ready() -> void:
    ray.add_exception(self)
    _highlight_material = ShaderMaterial.new()
    _highlight_material.shader = preload("res://shaders/block_highlight.gdshader")
    var outline_mesh := ImmediateMesh.new()
    outline_mesh.surface_begin(Mesh.PRIMITIVE_LINES, _highlight_material)
    var corners: Array[Vector3] = []
    for y in range(2):
        for x in range(2):
            for z in range(2):
                corners.append(Vector3(x, y, z))
    var edges := [[0,1],[0,2],[0,4],[1,3],[1,5],[2,3],[2,6],[3,7],[4,5],[4,6],[5,7],[6,7]]
    for edge in edges:
        outline_mesh.surface_add_vertex(corners[edge[0]])
        outline_mesh.surface_add_vertex(corners[edge[1]])
    outline_mesh.surface_end()
    highlight = MeshInstance3D.new()
    highlight.mesh = outline_mesh
    highlight.material_override = _highlight_material
    highlight.visible = false
    get_tree().current_scene.call_deferred("add_child", highlight)
    set_physics_process(false)

func configure(world_ref: VoxelWorld, creative: bool = false) -> void:
    world = world_ref
    is_creative = creative

func set_mobile_control(move: Vector2, sprinting: bool, jump_pressed: bool) -> void:
    mobile_move = move.limit_length(1.0)
    mobile_sprinting = sprinting
    mobile_jump = jump_pressed

func _physics_process(delta: float) -> void:
    if world != null:
        world.update_streaming(global_position, -1)
    var movement := Vector2.ZERO
    movement.x = Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
    movement.y = Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    movement += mobile_move
    movement = movement.limit_length(1.0)
    var direction := (global_transform.basis * Vector3(movement.x, 0.0, movement.y)).normalized()
    var sprinting := Input.is_action_pressed("sprint") or mobile_sprinting
    var speed := SPRINT_SPEED if sprinting else WALK_SPEED
    if is_creative and Input.is_key_pressed(KEY_CTRL): speed = 12.0
    velocity.x = move_toward(velocity.x, direction.x * speed, 22.0 * delta)
    velocity.z = move_toward(velocity.z, direction.z * speed, 22.0 * delta)
    if is_creative and Input.is_key_pressed(KEY_SPACE) and Input.is_key_pressed(KEY_CTRL):
        velocity.y = 5.0
    elif not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif velocity.y < 0.0:
        velocity.y = -0.8
    if (Input.is_action_just_pressed("jump") or mobile_jump) and is_on_floor():
        velocity.y = JUMP_VELOCITY
        mobile_jump = false
    if is_creative and Input.is_key_pressed(KEY_SHIFT):
        velocity.y = 6.0
    if Input.is_action_just_pressed("place_block"):
        place_target_block()
    var previous_y := global_position.y
    move_and_slide()
    if is_on_floor() and previous_y - global_position.y > 3.4 and not is_creative:
        take_damage((previous_y - global_position.y - 3.0) * 1.6)
    _update_target(delta)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        _rotate_camera(event.relative * look_sensitivity)
    elif event is InputEventMouseButton and event.pressed:
        if event.button_index == MOUSE_BUTTON_WHEEL_UP:
            inventory.select_slot(inventory.selected_slot - 1)
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
            inventory.select_slot(inventory.selected_slot + 1)
    elif event is InputEventScreenTouch:
        var view_size := get_viewport().get_visible_rect().size
        var camera_region: bool = event.position.x > view_size.x * 0.34 and event.position.y < view_size.y - 225.0
        if event.pressed and camera_region:
            _look_touch_id = event.index
            _last_touch_position = event.position
        elif not event.pressed and event.index == _look_touch_id:
            _look_touch_id = -1
    elif event is InputEventScreenDrag and event.index == _look_touch_id:
        var delta_pos: Vector2 = event.position - _last_touch_position
        _last_touch_position = event.position
        _rotate_camera(delta_pos * look_sensitivity * 1.45)

func _rotate_camera(amount: Vector2) -> void:
    rotate_y(-amount.x)
    camera_pitch = clampf(camera_pitch - amount.y, deg_to_rad(-86.0), deg_to_rad(86.0))
    camera.rotation.x = camera_pitch

func _update_target(delta: float) -> void:
    ray.force_raycast_update()
    if ray.is_colliding() and world != null:
        var hit_point: Vector3 = ray.get_collision_point()
        var normal: Vector3 = ray.get_collision_normal()
        var block_pos := Vector3i(floori(hit_point.x - normal.x * 0.012), floori(hit_point.y - normal.y * 0.012), floori(hit_point.z - normal.z * 0.012))
        var block_id := world.get_block(block_pos)
        if not block_id.is_empty():
            last_hit_block = block_id
            highlight.visible = true
            highlight.global_position = Vector3(block_pos) + Vector3(-0.002, -0.002, -0.002)
            highlight.scale = Vector3(1.004, 1.004, 1.004)
            var holding_break := break_held or Input.is_action_pressed("break_block")
            if holding_break:
                if mining_position != block_pos:
                    mining_position = block_pos
                    mining_progress = 0.0
                mining_progress += delta / maxf(0.15, float(BlockRegistryScript.get_block(block_id).get("hardness", 1.0)))
                _highlight_material.set_shader_parameter("line_color", Color(1.0, 0.34, 0.2, 0.98) if mining_progress > 0.45 else Color(1.0, 0.78, 0.35, 0.95))
                if mining_progress >= 1.0:
                    var def: Dictionary = BlockRegistryScript.get_block(block_id)
                    if world.set_block(block_pos, ""):
                        if not is_creative:
                            inventory.add_item(str(def.get("drop", block_id)), 1)
                        _show_block_particles(Vector3(block_pos) + Vector3.ONE * 0.5, Color(def.get("color", Color.WHITE)))
                    mining_progress = 0.0
                    mining_position = Vector3i(999999, 0, 0)
            elif mining_position != block_pos:
                mining_progress = 0.0
        else:
            highlight.visible = false
    else:
        highlight.visible = false
        mining_progress = 0.0

func try_break_target() -> void:
    break_held = true

func stop_break_target() -> void:
    break_held = false

func place_target_block() -> bool:
    if world == null:
        return false
    ray.force_raycast_update()
    if not ray.is_colliding():
        return false
    var hit_point: Vector3 = ray.get_collision_point()
    var normal: Vector3 = ray.get_collision_normal()
    var place_pos := Vector3i(floori(hit_point.x + normal.x * 0.02), floori(hit_point.y + normal.y * 0.02), floori(hit_point.z + normal.z * 0.02))
    var item_id := inventory.selected_item_id()
    if item_id.is_empty() or not BlockRegistryScript.has_block(item_id) or item_id in ["coal", "diamond", "stick", "wooden_pickaxe"]:
        return false
    if world.get_block(place_pos) != "":
        return false
    var player_box := AABB(global_position - Vector3(0.34, 0.0, 0.34), Vector3(0.68, 1.8, 0.68))
    if player_box.has_point(Vector3(place_pos) + Vector3(0.5, 0.5, 0.5)):
        return false
    if not is_creative and not inventory.remove_item(item_id, 1):
        return false
    return world.set_block(place_pos, item_id)

func take_damage(amount: float) -> void:
    if is_creative: return
    health = maxf(0.0, health - amount)
    if health <= 0.0:
        health = MAX_HEALTH
        hunger = 20.0
        if world != null:
            global_position = Vector3(0, world.height_at(0, 0) + 3, 0)
        velocity = Vector3.ZERO

func _show_block_particles(at: Vector3, color: Color) -> void:
    var particles := GPUParticles3D.new()
    particles.position = at
    particles.amount = 16
    particles.lifetime = 0.55
    particles.one_shot = true
    particles.explosiveness = 0.94
    var process_material := ParticleProcessMaterial.new()
    process_material.direction = Vector3.UP
    process_material.spread = 180.0
    process_material.initial_velocity_min = 1.1
    process_material.initial_velocity_max = 3.0
    process_material.gravity = Vector3(0, -8, 0)
    particles.process_material = process_material
    var draw_mesh := BoxMesh.new()
    draw_mesh.size = Vector3(0.07, 0.07, 0.07)
    var draw_material := StandardMaterial3D.new()
    draw_material.albedo_color = color
    draw_mesh.material = draw_material
    particles.draw_pass_1 = draw_mesh
    get_tree().current_scene.add_child(particles)
    particles.emitting = true
    get_tree().create_timer(0.9).timeout.connect(particles.queue_free)

func serialize_state() -> Dictionary:
    return {"position":[global_position.x, global_position.y, global_position.z], "rotation_y":rotation.y, "camera_pitch":camera_pitch, "health":health, "hunger":hunger, "inventory":inventory.serialize()}

func load_state(data: Dictionary) -> void:
    var pos: Variant = data.get("position", [])
    if pos is Array and pos.size() == 3:
        global_position = Vector3(float(pos[0]), float(pos[1]), float(pos[2]))
    rotation.y = float(data.get("rotation_y", 0.0))
    camera_pitch = clampf(float(data.get("camera_pitch", 0.0)), deg_to_rad(-86), deg_to_rad(86))
    camera.rotation.x = camera_pitch
    health = clampf(float(data.get("health", MAX_HEALTH)), 0.0, MAX_HEALTH)
    hunger = clampf(float(data.get("hunger", 20.0)), 0.0, 20.0)
    inventory.deserialize(data.get("inventory", {}))
