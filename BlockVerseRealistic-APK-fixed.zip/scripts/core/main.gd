extends Node

const WorldScript = preload("res://scripts/world/voxel_world.gd")
const PlayerScene = preload("res://scenes/player/player.tscn")
const HudScript = preload("res://scripts/ui/game_hud.gd")
const InventoryScript = preload("res://scripts/inventory/inventory_model.gd")
const BlockRegistryScript = preload("res://scripts/core/block_registry.gd")
const SaveScript = preload("res://scripts/saving/save_manager.gd")
const SettingsScript = preload("res://scripts/settings/settings_manager.gd")
const RecipesScript = preload("res://scripts/crafting/crafting_recipes.gd")
const EntityScript = preload("res://scripts/entities/entity_actor.gd")
const WildlifeScene = preload("res://scenes/entities/wildlife.tscn")

var world: VoxelWorld
var player: PlayerController
var hud: GameHUD
var canvas: CanvasLayer
var menu_root: Control
var panel_root: VBoxContainer
var notification_label: Label
var settings: Dictionary
var current_world: Dictionary = {}
var playing := false
var paused := false
var _autosave_timer := 0.0
var _active_panel := "main"
var _world_name_input: LineEdit
var _seed_input: LineEdit
var _mode_option: OptionButton
var _quality_option: OptionButton
var _fps_option: OptionButton
var _inventory_panel: PanelContainer
var _confirmation_action: Callable
var creatures: Array[Node] = []

func _ready() -> void:
    randomize()
    settings = SettingsScript.load_settings()
    Engine.max_fps = int(settings.fps)
    _create_world()
    _create_player()
    _create_ui()
    _show_main_menu()

func _create_world() -> void:
    world = WorldScript.new()
    world.name = "VoxelWorld"
    add_child(world)
    world.initialize_world(1337)
    world.set_quality(str(settings.quality))

func _create_player() -> void:
    player = PlayerScene.instantiate()
    player.name = "Player"
    world.add_child(player)
    player.configure(world, false)
    player.set_physics_process(false)
    player.visible = false

func _create_ui() -> void:
    canvas = CanvasLayer.new()
    canvas.layer = 10
    add_child(canvas)
    menu_root = Control.new()
    menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    menu_root.mouse_filter = Control.MOUSE_FILTER_PASS
    canvas.add_child(menu_root)
    hud = HudScript.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.visible = false
    canvas.add_child(hud)
    hud.jump_requested.connect(func() -> void: player.mobile_jump = true)
    hud.place_requested.connect(func() -> void: _place_block())
    hud.inventory_requested.connect(_toggle_inventory)
    hud.pause_requested.connect(_toggle_pause)
    hud.slot_selected.connect(func(index: int) -> void: player.inventory.select_slot(index))
    hud.break_started.connect(func() -> void: player.try_break_target())
    hud.break_stopped.connect(func() -> void: player.stop_break_target())
    notification_label = Label.new()
    notification_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    notification_label.offset_top = 20
    notification_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    notification_label.add_theme_font_size_override("font_size", 20)
    notification_label.add_theme_color_override("font_color", Color(1.0,0.82,0.48))
    notification_label.visible = false
    canvas.add_child(notification_label)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            if playing:
                _toggle_pause()
            else:
                _show_main_menu()
            get_viewport().set_input_as_handled()
        elif playing and not paused and event.keycode in [KEY_E, KEY_TAB]:
            _toggle_inventory()
            get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
    if playing and not paused:
        player.set_mobile_control(hud.move_vector, hud.sprinting, hud.jump_down)
        _autosave_timer += delta
        if _autosave_timer >= 35.0:
            _autosave_timer = 0.0
            _save_current_world(false)
        if player.global_position.y < -16.0:
            player.take_damage(100.0)
        queue_redraw_hud()

func queue_redraw_hud() -> void:
    hud.queue_redraw()

func _show_main_menu() -> void:
    _set_mouse_mode(false)
    hud.visible = false
    player.visible = false
    player.set_physics_process(false)
    _set_creatures_active(false)
    if is_instance_valid(player.highlight):
        player.highlight.visible = false
    playing = false
    paused = false
    _build_panel("main", "BLOCKVERSE", "REALISTIC  •  MOBILE SANDBOX")
    _add_spacer(16)
    _add_primary_button("Oyuna Devam Et", func() -> void: _continue_game())
    _add_primary_button("Yeni Dünya", func() -> void: _show_new_world())
    _add_secondary_button("Dünyalarım", func() -> void: _show_world_list())
    _add_secondary_button("Grafik ve Ses", func() -> void: _show_settings())
    _add_secondary_button("Kontroller", func() -> void: _show_controls())
    _add_secondary_button("Hakkında", func() -> void: _show_about())
    _add_footer("Sürüm 1.0.0  •  Çevrimdışı oynanır")

func _build_panel(panel_id: String, title_text: String, subtitle_text: String) -> void:
    _active_panel = panel_id
    for child in menu_root.get_children():
        child.queue_free()
    var shade := ColorRect.new()
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color = Color(0.015,0.026,0.037,0.56)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    menu_root.add_child(shade)
    var panel := PanelContainer.new()
    panel.name = "MenuPanel"
    panel.anchor_left = 0.055
    panel.anchor_right = 0.47
    panel.anchor_top = 0.075
    panel.anchor_bottom = 0.925
    panel.offset_left = 0
    panel.offset_right = 0
    panel.offset_top = 0
    panel.offset_bottom = 0
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.035,0.060,0.075,0.94)
    style.border_color = Color(0.75,0.59,0.34,0.85)
    style.set_border_width_all(1)
    style.corner_radius_top_left = 20
    style.corner_radius_top_right = 20
    style.corner_radius_bottom_left = 20
    style.corner_radius_bottom_right = 20
    style.content_margin_left = 28
    style.content_margin_right = 28
    style.content_margin_top = 28
    style.content_margin_bottom = 24
    panel.add_theme_stylebox_override("panel", style)
    menu_root.add_child(panel)
    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    panel.add_child(scroll)
    panel_root = VBoxContainer.new()
    panel_root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    panel_root.add_theme_constant_override("separation", 10)
    scroll.add_child(panel_root)
    var title := Label.new()
    title.text = title_text
    title.add_theme_font_size_override("font_size", 42 if panel_id == "main" else 30)
    title.add_theme_color_override("font_color", Color(0.95,0.78,0.48))
    panel_root.add_child(title)
    var subtitle := Label.new()
    subtitle.text = subtitle_text
    subtitle.add_theme_font_size_override("font_size", 12)
    subtitle.add_theme_color_override("font_color", Color(0.68,0.79,0.83))
    panel_root.add_child(subtitle)
    var line := HSeparator.new()
    panel_root.add_child(line)

func _add_spacer(min_height: float) -> void:
    var spacer := Control.new()
    spacer.custom_minimum_size.y = min_height
    panel_root.add_child(spacer)

func _add_primary_button(label_text: String, action: Callable) -> Button:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size.y = 52
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size", 18)
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.70,0.46,0.23,1.0)
    normal.corner_radius_top_left = 10
    normal.corner_radius_top_right = 10
    normal.corner_radius_bottom_left = 10
    normal.corner_radius_bottom_right = 10
    var hover := normal.duplicate()
    hover.bg_color = Color(0.83,0.58,0.30)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", hover)
    button.add_theme_stylebox_override("pressed", hover)
    button.add_theme_color_override("font_color", Color(0.07,0.08,0.07))
    button.pressed.connect(action)
    panel_root.add_child(button)
    return button

func _add_secondary_button(label_text: String, action: Callable) -> Button:
    var button := Button.new()
    button.text = label_text
    button.custom_minimum_size.y = 42
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color(0.10,0.16,0.19,0.92)
    normal.border_color = Color(0.32,0.44,0.47,0.55)
    normal.set_border_width_all(1)
    normal.corner_radius_top_left = 8
    normal.corner_radius_top_right = 8
    normal.corner_radius_bottom_left = 8
    normal.corner_radius_bottom_right = 8
    var hover := normal.duplicate()
    hover.bg_color = Color(0.15,0.25,0.28,0.98)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", hover)
    button.add_theme_stylebox_override("pressed", hover)
    button.add_theme_color_override("font_color", Color(0.86,0.92,0.93))
    button.pressed.connect(action)
    panel_root.add_child(button)
    return button

func _add_footer(text_value: String) -> void:
    var footer := Label.new()
    footer.text = text_value
    footer.add_theme_font_size_override("font_size", 11)
    footer.add_theme_color_override("font_color", Color(0.60,0.69,0.72))
    panel_root.add_child(footer)

func _show_new_world() -> void:
    _build_panel("new_world", "Yeni Dünya", "KENDİ DÜNYANI OLUŞTUR")
    var name_label := Label.new()
    name_label.text = "Dünya adı"
    panel_root.add_child(name_label)
    _world_name_input = LineEdit.new()
    _world_name_input.text = "Yeni Dünya"
    _world_name_input.placeholder_text = "Dünya adı"
    panel_root.add_child(_world_name_input)
    var seed_label := Label.new()
    seed_label.text = "Seed (boş = rastgele)"
    panel_root.add_child(seed_label)
    var seed_row := HBoxContainer.new()
    panel_root.add_child(seed_row)
    _seed_input = LineEdit.new()
    _seed_input.placeholder_text = "Örn. 20261018"
    _seed_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    seed_row.add_child(_seed_input)
    var random_button := Button.new()
    random_button.text = "Zar at"
    random_button.pressed.connect(func() -> void: _seed_input.text = str(randi_range(-2140000000,2140000000)))
    seed_row.add_child(random_button)
    var mode_label := Label.new()
    mode_label.text = "Oyun modu"
    panel_root.add_child(mode_label)
    _mode_option = OptionButton.new()
    _mode_option.add_item("Hayatta Kalma", 0)
    _mode_option.add_item("Yaratıcı", 1)
    panel_root.add_child(_mode_option)
    _add_primary_button("Dünyayı Oluştur", func() -> void: _create_new_world())
    _add_secondary_button("Geri", func() -> void: _show_main_menu())

func _create_new_world() -> void:
    var world_name := _world_name_input.text.strip_edges()
    if world_name.is_empty(): world_name = "Yeni Dünya"
    var seed_text := _seed_input.text.strip_edges()
    var seed_num := int(seed_text) if not seed_text.is_empty() else randi()
    var mode := "creative" if _mode_option.selected == 1 else "survival"
    _clear_creatures()
    var identifier := _slugify(world_name) + "_" + str(absi(seed_num) % 100000)
    current_world = {"id":identifier, "name":world_name, "seed":seed_num, "mode":mode, "created_at":Time.get_datetime_string_from_system(), "last_played":Time.get_datetime_string_from_system()}
    world.initialize_world(seed_num)
    player.configure(world, mode == "creative")
    player.inventory = InventoryScript.new()
    _give_starting_items()
    var spawn_y := world.height_at(0,0) + 3
    player.global_position = Vector3(0.5, spawn_y, 0.5)
    _start_game()
    _notify("Dünya oluşturuldu · Seed %d" % seed_num)
    _save_current_world(false)

func _give_starting_items() -> void:
    player.inventory.add_item("wood", 8)
    player.inventory.add_item("stone", 24)
    player.inventory.add_item("dirt", 16)
    player.inventory.add_item("planks", 8)
    player.inventory.add_item("torch", 4)
    if player.is_creative:
        for id in BlockRegistryScript.ids():
            if not str(id).ends_with("_ore"):
                player.inventory.add_item(str(id), 64)

func _continue_game() -> void:
    if current_world.is_empty():
        var worlds := SaveScript.list_worlds()
        if worlds.is_empty():
            _show_new_world()
            return
        var result: Dictionary = SaveScript.load_world(str(worlds[0].id))
        if not result.ok:
            _notify(str(result.error))
            _show_world_list()
            return
        _apply_saved_world(result.data)
    _start_game()

func _apply_saved_world(data: Dictionary) -> void:
    _clear_creatures()
    current_world = {"id":str(data.get("id", "world")), "name":str(data.get("name", "Dünya")), "seed":int(data.get("seed", 1337)), "mode":str(data.get("mode", "survival")), "last_played":Time.get_datetime_string_from_system()}
    world.initialize_world(int(current_world.seed), data.get("edits", []))
    player.configure(world, str(current_world.mode) == "creative")
    player.load_state(data.get("player", {}))

func _start_game() -> void:
    playing = true
    paused = false
    menu_root.visible = false
    hud.visible = true
    player.visible = true
    player.set_physics_process(true)
    _set_creatures_active(true)
    world.update_streaming(player.global_position, -1)
    _set_mouse_mode(true)
    if current_world.is_empty():
        current_world = {"id":"quick_world", "name":"Dünya", "seed":1337, "mode":"survival"}
    player.configure(world, str(current_world.get("mode", "survival")) == "creative")
    if player.inventory.count_item("wood") == 0:
        _give_starting_items()
    if creatures.is_empty():
        _spawn_creatures()
    _save_current_world(false)

func _toggle_pause() -> void:
    if not playing: return
    if paused:
        paused = false
        menu_root.visible = false
        hud.visible = true
        player.set_physics_process(true)
        _set_creatures_active(true)
        _set_mouse_mode(true)
    else:
        paused = true
        _save_current_world(false)
        player.set_physics_process(false)
        _set_creatures_active(false)
        menu_root.visible = true
        hud.visible = false
        _set_mouse_mode(false)
        _build_panel("pause", "Duraklatıldı", str(current_world.get("name", "Dünya")))
        _add_primary_button("Oyuna Dön", func() -> void: _toggle_pause())
        _add_secondary_button("Dünyayı Kaydet", func() -> void: _save_current_world(true))
        _add_secondary_button("Ayarlar", func() -> void: _show_settings(true))
        _add_secondary_button("Ana Menü", func() -> void:
            _save_current_world(false)
            _show_main_menu()
        )

func _toggle_inventory() -> void:
    if not playing or paused: return
    if is_instance_valid(_inventory_panel):
        _inventory_panel.queue_free()
        _inventory_panel = null
        return
    _inventory_panel = PanelContainer.new()
    _inventory_panel.anchor_left = 0.52
    _inventory_panel.anchor_right = 0.96
    _inventory_panel.anchor_top = 0.14
    _inventory_panel.anchor_bottom = 0.82
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.025,0.05,0.065,0.97)
    style.border_color = Color(0.82,0.64,0.36,0.9)
    style.set_border_width_all(1)
    style.corner_radius_top_left=16
    style.corner_radius_top_right=16
    style.corner_radius_bottom_left=16
    style.corner_radius_bottom_right=16
    _inventory_panel.add_theme_stylebox_override("panel", style)
    canvas.add_child(_inventory_panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 7)
    _inventory_panel.add_child(box)
    var title := Label.new()
    title.text = "ENVANTER & ÜRETİM"
    title.add_theme_font_size_override("font_size", 22)
    box.add_child(title)
    var grid := GridContainer.new()
    grid.columns = 3
    box.add_child(grid)
    for slot in player.inventory.slots:
        var item_button := Button.new()
        var id := str(slot.id)
        item_button.text = "Boş" if id.is_empty() else "%s × %d" % [BlockRegistryScript.block_name(id), int(slot.count)]
        item_button.custom_minimum_size = Vector2(120, 42)
        item_button.pressed.connect(func() -> void:
            if not id.is_empty():
                player.inventory.select_slot(player.inventory.slots.find(slot))
                _notify(BlockRegistryScript.block_name(id) + " seçildi")
        )
        grid.add_child(item_button)
    var recipe_title := Label.new()
    recipe_title.text = "Hızlı üretim"
    box.add_child(recipe_title)
    for recipe_id in RecipesScript.RECIPES:
        var recipe: Dictionary = RecipesScript.RECIPES[recipe_id]
        var recipe_button := Button.new()
        recipe_button.text = str(recipe.name) + "  ·  " + ("Üret" if RecipesScript.can_craft(player.inventory, str(recipe_id)) else "Malzeme eksik")
        recipe_button.disabled = not RecipesScript.can_craft(player.inventory, str(recipe_id))
        recipe_button.pressed.connect(func() -> void:
            if RecipesScript.craft(player.inventory, str(recipe_id)):
                _notify(str(recipe.name) + " üretildi")
                _toggle_inventory()
                _toggle_inventory()
        )
        box.add_child(recipe_button)
    var close := Button.new()
    close.text = "Kapat"
    close.pressed.connect(_toggle_inventory)
    box.add_child(close)

func _show_world_list() -> void:
    _build_panel("worlds", "Dünyalarım", "KAYITLI DÜNYALAR")
    var worlds := SaveScript.list_worlds()
    if worlds.is_empty():
        var empty := Label.new()
        empty.text = "Henüz kayıtlı dünya yok.\nYeni bir dünya oluşturarak başlayabilirsin."
        empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        panel_root.add_child(empty)
    else:
        for world_info in worlds:
            var row := HBoxContainer.new()
            panel_root.add_child(row)
            var details := Label.new()
            details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            details.text = "%s\nSeed: %s · %s" % [world_info.name, str(world_info.seed), str(world_info.mode)]
            row.add_child(details)
            var load_button := Button.new()
            load_button.text = "Aç"
            load_button.pressed.connect(func() -> void:
                var result := SaveScript.load_world(str(world_info.id))
                if result.ok:
                    _apply_saved_world(result.data)
                    _start_game()
                else:
                    _notify(str(result.error))
            )
            row.add_child(load_button)
            var delete_button := Button.new()
            delete_button.text = "Sil"
            delete_button.pressed.connect(func() -> void: _confirm_delete_world(str(world_info.id), str(world_info.name)))
            row.add_child(delete_button)
    _add_primary_button("Yeni Dünya", func() -> void: _show_new_world())
    _add_secondary_button("Geri", func() -> void: _show_main_menu())

func _confirm_delete_world(world_id: String, world_name: String) -> void:
    var dialog := ConfirmationDialog.new()
    dialog.title = "Dünyayı sil"
    dialog.dialog_text = "'%s' kalıcı olarak silinsin mi?" % world_name
    canvas.add_child(dialog)
    dialog.confirmed.connect(func() -> void:
        SaveScript.delete_world(world_id)
        dialog.queue_free()
        _show_world_list()
    )
    dialog.canceled.connect(func() -> void: dialog.queue_free())
    dialog.popup_centered(Vector2i(420, 180))

func _show_settings(from_pause: bool = false) -> void:
    _build_panel("settings", "Ayarlar", "GÖRÜNTÜ VE SES")
    var qlabel := Label.new()
    qlabel.text = "Grafik kalitesi"
    panel_root.add_child(qlabel)
    _quality_option = OptionButton.new()
    _quality_option.add_item("Düşük", 0)
    _quality_option.add_item("Orta",1)
    _quality_option.add_item("Yüksek",2)
    _quality_option.selected = {"low":0,"medium":1,"high":2}.get(str(settings.quality),1)
    panel_root.add_child(_quality_option)
    var flabel := Label.new()
    flabel.text = "Kare hızı"
    panel_root.add_child(flabel)
    _fps_option = OptionButton.new()
    _fps_option.add_item("30 FPS",30)
    _fps_option.add_item("60 FPS",60)
    _fps_option.select(0 if int(settings.fps)==30 else 1)
    panel_root.add_child(_fps_option)
    var audio_label := Label.new()
    audio_label.text = "Ana ses seviyesi"
    panel_root.add_child(audio_label)
    var volume := HSlider.new()
    volume.min_value=0
    volume.max_value=1
    volume.step=0.05
    volume.value=float(settings.master_volume)
    panel_root.add_child(volume)
    _add_primary_button("Ayarları Kaydet", func() -> void:
        settings.quality = ["low","medium","high"][_quality_option.selected]
        settings.fps = int(_fps_option.get_item_id(_fps_option.selected))
        settings.master_volume = volume.value
        Engine.max_fps = int(settings.fps)
        world.set_quality(str(settings.quality))
        SettingsScript.save_settings(settings)
        _notify("Ayarlar kaydedildi")
        if from_pause: _toggle_pause()
        else: _show_main_menu()
    )
    _add_secondary_button("Geri", func() -> void: _toggle_pause() if from_pause else _show_main_menu())

func _show_controls() -> void:
    _build_panel("controls", "Kontroller", "PC VE DOKUNMATİK")
    var label := Label.new()
    label.text = "PC\nW A S D  — Hareket\nFare  — Kamera\nBoşluk  — Zıpla\nSol tık basılı  — Blok kır\nSağ tık  — Blok yerleştir\n1–9 / fare tekerleği — Hotbar\nEsc — Duraklat\n\nMOBİL\nSol joystick — Hareket\nSağ alanı sürükle — Kamera\nZIPLA / KIR / KOY — Eylemler\nÇANTA — Envanter ve üretim\nⅡ — Duraklat"
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.add_theme_font_size_override("font_size",16)
    panel_root.add_child(label)
    _add_secondary_button("Geri", func() -> void: _show_main_menu())

func _show_about() -> void:
    _build_panel("about", "BlockVerse Realistic", "ÖZGÜR BİR BLOK DÜNYASI")
    var label := Label.new()
    label.text = "Prosedürel voxel arazi, blok madenciliği, yerleştirme, envanter, üretim ve yerel dünya kayıtları.\n\nBu proje Godot 4.7.2 Stable ile hazırlanmıştır. Çevrimdışı oynanış hedeflenir.\n\nGörseller ve materyaller bu projeye özgü prosedürel olarak oluşturulur."
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    panel_root.add_child(label)
    _add_secondary_button("Geri", func() -> void: _show_main_menu())

func _spawn_creatures() -> void:
    var spawn_offsets: Array[Dictionary] = [
        {"offset":Vector3(6, 0, 4), "behavior":"passive", "color":Color(0.66, 0.43, 0.29)},
        {"offset":Vector3(-8, 0, -5), "behavior":"hostile", "color":Color(0.26, 0.20, 0.24)}
    ]
    for spec in spawn_offsets:
        var actor: EntityActor = WildlifeScene.instantiate()
        actor.behavior = str(spec.behavior)
        var body_material := StandardMaterial3D.new()
        body_material.albedo_color = spec.color
        body_material.roughness = 0.9
        actor.get_node("Body").material_override = body_material
        actor.get_node("Head").material_override = body_material
        var offset: Vector3 = spec.offset
        var x := int(floori(offset.x))
        var z := int(floori(offset.z))
        actor.configure(world, player)
        world.add_child(actor)
        actor.global_position = Vector3(offset.x, world.height_at(x, z) + 2.0, offset.z)
        creatures.append(actor)

func _clear_creatures() -> void:
    for actor in creatures:
        if is_instance_valid(actor):
            actor.queue_free()
    creatures.clear()

func _set_creatures_active(active: bool) -> void:
    for actor in creatures:
        if is_instance_valid(actor):
            actor.set_physics_process(active)

func _place_block() -> void:
    if not playing or paused: return
    if player.place_target_block(): _notify("Blok yerleştirildi")

func _save_current_world(show_message: bool) -> void:
    if current_world.is_empty() or world == null or player == null: return
    current_world.last_played = Time.get_datetime_string_from_system()
    var payload := {"id":str(current_world.get("id","world")), "name":str(current_world.get("name","Dünya")), "seed":int(current_world.get("seed",world.seed_value)), "mode":str(current_world.get("mode","survival")), "last_played":str(current_world.last_played), "player":player.serialize_state(), "edits":world.serialize_edits()}
    var ok := SaveScript.save_world(str(current_world.id), payload)
    if show_message: _notify("Dünya kaydedildi" if ok else "Kayıt hatası: disk yazılamadı")

func _notify(message: String) -> void:
    notification_label.text = message
    notification_label.visible = true
    var timer := get_tree().create_timer(2.4)
    timer.timeout.connect(func() -> void:
        if is_instance_valid(notification_label):
            notification_label.visible = false
    )

func _slugify(input_text: String) -> String:
    var result := ""
    for ch in input_text.to_lower():
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789": result += ch
        elif ch == " " or ch == "-" or ch == "_": result += "_"
    while "__" in result: result = result.replace("__", "_")
    return result.strip_edges().trim_prefix("_").trim_suffix("_") if not result.is_empty() else "world"

func _set_mouse_mode(capture: bool) -> void:
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if capture and not OS.has_feature("mobile") else Input.MOUSE_MODE_VISIBLE

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if playing and not paused: _toggle_pause()
        elif not playing: _show_main_menu()
    elif what == NOTIFICATION_APPLICATION_PAUSED:
        if playing:
            _save_current_world(false)
            paused = true
            player.set_physics_process(false)
            _set_creatures_active(false)
    elif what == NOTIFICATION_APPLICATION_RESUMED:
        if playing and paused:
            menu_root.visible = true
            hud.visible = false
            _toggle_pause()
