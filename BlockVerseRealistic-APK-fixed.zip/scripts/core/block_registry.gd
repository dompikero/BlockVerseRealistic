extends RefCounted
class_name BlockRegistry

const AIR := ""
const BLOCKS := {
    "grass": {"name":"Çimenli toprak", "color":Color(0.34,0.52,0.24), "hardness":0.7, "transparent":false, "drop":"grass", "stack":64},
    "dirt": {"name":"Toprak", "color":Color(0.42,0.29,0.19), "hardness":0.55, "transparent":false, "drop":"dirt", "stack":64},
    "stone": {"name":"Taş", "color":Color(0.42,0.45,0.47), "hardness":1.8, "transparent":false, "drop":"stone", "stack":64},
    "sand": {"name":"Kum", "color":Color(0.77,0.69,0.48), "hardness":0.45, "transparent":false, "drop":"sand", "stack":64},
    "gravel": {"name":"Çakıl", "color":Color(0.53,0.52,0.50), "hardness":0.6, "transparent":false, "drop":"gravel", "stack":64},
    "snow": {"name":"Kar", "color":Color(0.88,0.93,0.98), "hardness":0.35, "transparent":false, "drop":"snow", "stack":64},
    "wood": {"name":"Kütük", "color":Color(0.38,0.25,0.14), "hardness":1.8, "transparent":false, "drop":"wood", "stack":64},
    "leaves": {"name":"Yaprak", "color":Color(0.19,0.38,0.16), "hardness":0.25, "transparent":true, "drop":"leaves", "stack":64},
    "glass": {"name":"Cam", "color":Color(0.68,0.88,0.92,0.42), "hardness":0.35, "transparent":true, "drop":"glass", "stack":64},
    "coal_ore": {"name":"Kömür cevheri", "color":Color(0.23,0.24,0.25), "hardness":2.1, "transparent":false, "drop":"coal", "stack":64},
    "iron_ore": {"name":"Demir cevheri", "color":Color(0.62,0.43,0.32), "hardness":2.8, "transparent":false, "drop":"iron_ore", "stack":64},
    "copper_ore": {"name":"Bakır cevheri", "color":Color(0.68,0.37,0.22), "hardness":2.4, "transparent":false, "drop":"copper_ore", "stack":64},
    "gold_ore": {"name":"Altın cevheri", "color":Color(0.91,0.68,0.12), "hardness":3.2, "transparent":false, "drop":"gold_ore", "stack":64},
    "diamond_ore": {"name":"Elmas cevheri", "color":Color(0.25,0.78,0.83), "hardness":3.7, "transparent":false, "drop":"diamond", "stack":64},
    "planks": {"name":"Kalas", "color":Color(0.60,0.41,0.24), "hardness":1.1, "transparent":false, "drop":"planks", "stack":64},
    "torch": {"name":"Meşale", "color":Color(1.0,0.65,0.21), "hardness":0.1, "transparent":true, "drop":"torch", "stack":64},
    "chest": {"name":"Sandık", "color":Color(0.48,0.29,0.13), "hardness":2.0, "transparent":false, "drop":"chest", "stack":16},
    "furnace": {"name":"Fırın", "color":Color(0.34,0.35,0.37), "hardness":3.2, "transparent":false, "drop":"furnace", "stack":16},
    "crafting_table": {"name":"Çalışma masası", "color":Color(0.54,0.34,0.19), "hardness":2.0, "transparent":false, "drop":"crafting_table", "stack":16},
    "fence": {"name":"Çit", "color":Color(0.57,0.39,0.23), "hardness":1.2, "transparent":true, "drop":"fence", "stack":64},
    "door": {"name":"Kapı", "color":Color(0.46,0.30,0.17), "hardness":1.4, "transparent":true, "drop":"door", "stack":16}
}
static func has_block(block_id: String) -> bool:
    return BLOCKS.has(block_id)
static func get_block(block_id: String) -> Dictionary:
    return BLOCKS.get(block_id, {})
static func ids() -> Array:
    return BLOCKS.keys()
static func block_name(block_id: String) -> String:
    return str(BLOCKS.get(block_id, {}).get("name", block_id))
static func is_transparent(block_id: String) -> bool:
    return bool(BLOCKS.get(block_id, {}).get("transparent", false))
