extends RefCounted
class_name InventoryModel

const SLOT_COUNT := 9
const MAX_STACK := 64
var slots: Array[Dictionary] = []
var selected_slot: int = 0

func _init() -> void:
    slots.clear()
    for i in range(SLOT_COUNT):
        slots.append({"id":"", "count":0})

func count_item(item_id: String) -> int:
    var total := 0
    for slot in slots:
        if str(slot.get("id", "")) == item_id:
            total += int(slot.get("count", 0))
    return total

func add_item(item_id: String, amount: int) -> int:
    if item_id.is_empty() or amount <= 0:
        return maxi(amount, 0)
    var remaining := amount
    var max_stack := 1 if item_id.ends_with("_pickaxe") or item_id.ends_with("_axe") else MAX_STACK
    for slot in slots:
        if slot.id == item_id and int(slot.count) < max_stack:
            var moved := mini(remaining, max_stack - int(slot.count))
            slot.count = int(slot.count) + moved
            remaining -= moved
            if remaining <= 0:
                return 0
    for slot in slots:
        if str(slot.id).is_empty() or int(slot.count) <= 0:
            var moved := mini(remaining, max_stack)
            slot.id = item_id
            slot.count = moved
            remaining -= moved
            if remaining <= 0:
                return 0
    return remaining

func remove_item(item_id: String, amount: int) -> bool:
    if amount <= 0:
        return true
    if count_item(item_id) < amount:
        return false
    var remaining := amount
    for slot in slots:
        if slot.id == item_id and remaining > 0:
            var moved := mini(remaining, int(slot.count))
            slot.count = int(slot.count) - moved
            remaining -= moved
            if int(slot.count) <= 0:
                slot.id = ""
                slot.count = 0
    return remaining == 0

func select_slot(index: int) -> void:
    selected_slot = clampi(index, 0, SLOT_COUNT - 1)

func selected_item_id() -> String:
    return str(slots[selected_slot].get("id", ""))

func serialize() -> Dictionary:
    var result: Array = []
    for slot in slots:
        result.append({"id":str(slot.get("id", "")), "count":int(slot.get("count", 0))})
    return {"slots":result, "selected_slot":selected_slot}

func deserialize(data: Dictionary) -> bool:
    var incoming: Variant = data.get("slots", [])
    if not incoming is Array or incoming.size() != SLOT_COUNT:
        return false
    var parsed: Array[Dictionary] = []
    for raw in incoming:
        if not raw is Dictionary:
            return false
        var item_id := str(raw.get("id", ""))
        var count := int(raw.get("count", 0))
        if count < 0 or count > MAX_STACK or (count > 0 and item_id.is_empty()):
            return false
        parsed.append({"id":item_id, "count":count})
    slots = parsed
    selected_slot = clampi(int(data.get("selected_slot", 0)), 0, SLOT_COUNT - 1)
    return true
