extends RefCounted
class_name SettingsManager

const SETTINGS_PATH := "user://settings.json"
const DEFAULTS := {"quality":"medium", "fps":60, "master_volume":0.8, "effects_volume":0.85, "music_volume":0.45, "show_tutorial":true}

static func load_settings() -> Dictionary:
    if not FileAccess.file_exists(SETTINGS_PATH):
        return DEFAULTS.duplicate(true)
    var file := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
    if file == null:
        return DEFAULTS.duplicate(true)
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if not parsed is Dictionary:
        return DEFAULTS.duplicate(true)
    var result := DEFAULTS.duplicate(true)
    for key in DEFAULTS:
        if parsed.has(key):
            result[key] = parsed[key]
    if not result.quality in ["low", "medium", "high"]:
        result.quality = "medium"
    result.fps = 30 if int(result.fps) == 30 else 60
    return result

static func save_settings(settings: Dictionary) -> bool:
    var normalized := DEFAULTS.duplicate(true)
    for key in normalized:
        if settings.has(key):
            normalized[key] = settings[key]
    var file := FileAccess.open(SETTINGS_PATH + ".tmp", FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify(normalized, "\t"))
    file.flush()
    file.close()
    if FileAccess.file_exists(SETTINGS_PATH):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(SETTINGS_PATH))
    return DirAccess.rename_absolute(ProjectSettings.globalize_path(SETTINGS_PATH + ".tmp"), ProjectSettings.globalize_path(SETTINGS_PATH)) == OK
