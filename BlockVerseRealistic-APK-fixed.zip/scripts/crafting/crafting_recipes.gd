extends RefCounted
class_name CraftingRecipes

const RECIPES := {
    "planks": {"name":"Kalas", "ingredients":{"wood":1}, "output":"planks", "count":4},
    "sticks": {"name":"Çubuk", "ingredients":{"planks":2}, "output":"stick", "count":4},
    "crafting_table": {"name":"Çalışma masası", "ingredients":{"planks":4}, "output":"crafting_table", "count":1},
    "torch": {"name":"Meşale", "ingredients":{"coal":1,"stick":1}, "output":"torch", "count":4},
    "wooden_pickaxe": {"name":"Ahşap kazma", "ingredients":{"planks":3,"stick":2}, "output":"wooden_pickaxe", "count":1},
    "furnace": {"name":"Fırın", "ingredients":{"stone":8}, "output":"furnace", "count":1}
}

static func can_craft(inventory: InventoryModel, recipe_id: String) -> bool:
    if not RECIPES.has(recipe_id):
        return false
    var recipe: Dictionary = RECIPES[recipe_id]
    for ingredient in recipe.ingredients:
        if inventory.count_item(str(ingredient)) < int(recipe.ingredients[ingredient]):
            return false
    var output_id := str(recipe.output)
    var output_count := int(recipe.count)
    var probe := InventoryModel.new()
    probe.deserialize(inventory.serialize())
    for ingredient in recipe.ingredients:
        probe.remove_item(str(ingredient), int(recipe.ingredients[ingredient]))
    return probe.add_item(output_id, output_count) == 0

static func craft(inventory: InventoryModel, recipe_id: String) -> bool:
    if not can_craft(inventory, recipe_id):
        return false
    var recipe: Dictionary = RECIPES[recipe_id]
    for ingredient in recipe.ingredients:
        if not inventory.remove_item(str(ingredient), int(recipe.ingredients[ingredient])):
            return false
    return inventory.add_item(str(recipe.output), int(recipe.count)) == 0
