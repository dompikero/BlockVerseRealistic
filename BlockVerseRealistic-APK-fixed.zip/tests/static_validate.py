#!/usr/bin/env python3
"""Dependency-free structural checks for BlockVerse; not a Godot compiler."""
from pathlib import Path
import re
import struct
import sys
import zlib

ROOT = Path(__file__).resolve().parents[1]
errors = []
checked_refs = 0

# Verify every explicitly referenced res:// path in project text resources.
resource_exts = {".gd", ".tscn", ".tres", ".godot", ".cfg", ".gdshader"}
for source in ROOT.rglob("*"):
    if not source.is_file() or source.suffix not in resource_exts:
        continue
    try:
        text = source.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        errors.append(f"Cannot decode UTF-8: {source.relative_to(ROOT)}")
        continue
    for raw_ref in re.findall(r"res://[^\s\"'<>]+", text):
        ref = raw_ref.rstrip(",);]}")
        checked_refs += 1
        target = ROOT / ref.removeprefix("res://")
        if not target.exists():
            errors.append(f"Missing resource {ref} (referenced by {source.relative_to(ROOT)})")

project = (ROOT / "project.godot").read_text(encoding="utf-8")
preset = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
required = [
    ("main scene", 'run/main_scene="res://scenes/main/main.tscn"' in project),
    ("Android package id", 'package/unique_name="com.blockverse.realistic"' in preset),
    ("ARM64-only preset", "architectures/arm64-v8a=true" in preset and "architectures/armeabi-v7a=false" in preset),
    ("pinned Godot workflow", "GODOT_VERSION: 4.7.2" in workflow),
    ("current Android SDK setup action", "uses: android-actions/setup-android@v4" in workflow),
    ("Godot SDK tools compatibility alias", 'LATEST_DIR="$ANDROID_HOME/cmdline-tools/latest"' in workflow and 'ln -s "$TOOLS_DIR" "$LATEST_DIR"' in workflow),
    ("version-independent apkanalyzer discovery", "find \"$ANDROID_HOME/cmdline-tools\" -type f -path '*/bin/apkanalyzer'" in workflow),
    ("successful-only APK artifact", "if: success()" in workflow and "BlockVerse-Realistic-Android-APK" in workflow),
    ("always-on failure report", "id: generate_report" in workflow and "if: always()" in workflow and "BlockVerse-Build-Report-and-Logs" in workflow),
]
for label, ok in required:
    if not ok:
        errors.append(f"Required configuration missing/incorrect: {label}")

# Verify icon PNG chunk boundaries and CRCs using only the standard library.
for image in (ROOT / "assets/icons").glob("*.png"):
    data = image.read_bytes()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        errors.append(f"Invalid PNG signature: {image.relative_to(ROOT)}")
        continue
    offset = 8
    saw_iend = False
    while offset + 12 <= len(data):
        size = struct.unpack(">I", data[offset:offset+4])[0]
        end = offset + 12 + size
        if end > len(data):
            errors.append(f"Truncated PNG chunk: {image.relative_to(ROOT)}")
            break
        chunk_type = data[offset+4:offset+8]
        chunk_data = data[offset+8:offset+8+size]
        expected_crc = struct.unpack(">I", data[offset+8+size:end])[0]
        if zlib.crc32(chunk_type + chunk_data) & 0xffffffff != expected_crc:
            errors.append(f"Bad PNG CRC: {image.relative_to(ROOT)}")
            break
        offset = end
        if chunk_type == b"IEND":
            saw_iend = True
            break
    if not saw_iend or offset != len(data):
        errors.append(f"PNG has missing IEND or trailing data: {image.relative_to(ROOT)}")

print(f"Structural resource references checked: {checked_refs}")
print(f"PNG icons checked: {len(list((ROOT / 'assets/icons').glob('*.png')))}")
if errors:
    for error in errors:
        print(f"ERROR: {error}", file=sys.stderr)
    raise SystemExit(1)
print("STATIC SOURCE CHECKS: PASS (does not replace Godot import, GDScript, shader, gameplay, or APK tests)")
