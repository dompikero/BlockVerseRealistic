extends SceneTree

const BlockRegistryScript = preload("res://scripts/core/block_registry.gd")
const GeneratorScript = preload("res://scripts/world/world_generator.gd")
const InventoryScript = preload("res://scripts/inventory/inventory_model.gd")
const RecipesScript = preload("res://scripts/crafting/crafting_recipes.gd")
const SaveScript = preload("res://scripts/saving/save_manager.gd")
const SettingsScript = preload("res://scripts/settings/settings_manager.gd")
var failures: Array[String] = []
var passed := 0

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    _test("block registry", func() -> bool: return BlockRegistryScript.has_block("grass") and BlockRegistryScript.has_block("diamond_ore") and not BlockRegistryScript.has_block("missing") and BlockRegistryScript.get_block("stone").hardness > 0)
    _test("seed repeatability", func() -> bool:
        var a := GeneratorScript.new()
        a.configure(424242)
        var b := GeneratorScript.new()
        b.configure(424242)
        for x in range(-20,21,4):
            for z in range(-20,21,4):
                if a.height_at(x,z) != b.height_at(x,z) or a.biome_at(x,z) != b.biome_at(x,z): return false
        return true
    )
    _test("world coordinate bounds", func() -> bool:
        var generator := GeneratorScript.new()
        generator.configure(17)
        var high := generator.height_at(0,0)
        return high >= 5 and high < GeneratorScript.WORLD_HEIGHT and generator.block_at(Vector3i(0, GeneratorScript.WORLD_HEIGHT, 0)).is_empty()
    )
    _test("inventory stack cap and add/remove", func() -> bool:
        var inv := InventoryScript.new()
        var remaining := inv.add_item("stone", 130)
        return remaining == 0 and inv.count_item("stone") == 130 and inv.remove_item("stone", 65) and inv.count_item("stone") == 65
    )
    _test("inventory invalid remove is atomic", func() -> bool:
        var inv := InventoryScript.new()
        inv.add_item("wood", 3)
        return not inv.remove_item("wood", 5) and inv.count_item("wood") == 3
    )
    _test("crafting recipe validates ingredients", func() -> bool:
        var inv := InventoryScript.new()
        if RecipesScript.can_craft(inv, "planks"): return false
        inv.add_item("wood", 1)
        return RecipesScript.can_craft(inv, "planks") and RecipesScript.craft(inv, "planks") and inv.count_item("planks") == 4 and inv.count_item("wood") == 0
    )
    _test("save/load roundtrip", func() -> bool:
        var payload := {"name":"test_world", "seed":123456, "mode":"creative", "edits":[{"x":1,"y":7,"z":-2,"id":"glass"}]}
        if not SaveScript.save_world("test_world_ci", payload): return false
        var loaded := SaveScript.load_world("test_world_ci")
        var ok: bool = loaded.ok and loaded.data.seed == 123456 and loaded.data.edits.size() == 1 and loaded.data.edits[0].id == "glass"
        SaveScript.delete_world("test_world_ci")
        return ok
    )
    _test("corrupt save handled safely", func() -> bool:
        var path := SaveScript.save_path("corrupt_ci")
        var file := FileAccess.open(path, FileAccess.WRITE)
        if file == null: return false
        file.store_string("{ definitely not json")
        file.close()
        var result := SaveScript.load_world("corrupt_ci")
        SaveScript.delete_world("corrupt_ci")
        return not result.ok and result.has("error")
    )
    _test("settings persistence", func() -> bool:
        var previous := SettingsScript.load_settings()
        var modified := previous.duplicate(true)
        modified.quality = "low"
        modified.fps = 30
        if not SettingsScript.save_settings(modified): return false
        var loaded := SettingsScript.load_settings()
        var ok: bool = loaded.quality == "low" and int(loaded.fps) == 30
        SettingsScript.save_settings(previous)
        return ok
    )
    print("\nBlockVerse test result: %d passed, %d failed" % [passed, failures.size()])
    for failure in failures: push_error(failure)
    quit(0 if failures.is_empty() else 1)

func _test(title: String, check: Callable) -> void:
    var result: bool = false
    var error_message := ""
    var output: Variant = check.call()
    result = bool(output)
    if result:
        passed += 1
        print("PASS: " + title)
    else:
        failures.append("FAIL: " + title)
        push_error("FAIL: " + title)
